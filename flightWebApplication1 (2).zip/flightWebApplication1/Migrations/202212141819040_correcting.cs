﻿namespace flightWebApplication1.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class correcting : DbMigration
    {
        public override void Up()
        {
            DropForeignKey("dbo.Bookings", "Flight_Id", "dbo.Flights");
            DropIndex("dbo.Bookings", new[] { "Flight_Id" });
            RenameColumn(table: "dbo.Bookings", name: "Flight_Id", newName: "Flight_Flight_Id");
            RenameColumn(table: "dbo.Bookings", name: "Email", newName: "Registration_Email");
            RenameIndex(table: "dbo.Bookings", name: "IX_Email", newName: "IX_Registration_Email");
            AlterColumn("dbo.Bookings", "Flight_Flight_Id", c => c.Int());
            CreateIndex("dbo.Bookings", "Flight_Flight_Id");
            AddForeignKey("dbo.Bookings", "Flight_Flight_Id", "dbo.Flights", "FlightId");
        }
        
        public override void Down()
        {
            DropForeignKey("dbo.Bookings", "Flight_Flight_Id", "dbo.Flights");
            DropIndex("dbo.Bookings", new[] { "Flight_Flight_Id" });
            AlterColumn("dbo.Bookings", "Flight_Flight_Id", c => c.Int(nullable: false));
            RenameIndex(table: "dbo.Bookings", name: "IX_Registration_Email", newName: "IX_Email");
            RenameColumn(table: "dbo.Bookings", name: "Registration_Email", newName: "Email");
            RenameColumn(table: "dbo.Bookings", name: "Flight_Flight_Id", newName: "Flight_Id");
            CreateIndex("dbo.Bookings", "Flight_Id");
            AddForeignKey("dbo.Bookings", "Flight_Id", "dbo.Flights", "FlightId", cascadeDelete: true);
        }
    }
}
