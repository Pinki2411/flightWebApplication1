﻿namespace flightWebApplication1.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class rr : DbMigration
    {
        public override void Up()
        {
            CreateTable(
                "dbo.Bookings",
                c => new
                    {
                        Booking_id = c.Int(nullable: false, identity: true),
                        Passenger_Name = c.String(nullable: false),
                        City = c.String(nullable: false),
                        Country = c.String(nullable: false),
                        Passport_No = c.String(nullable: false, maxLength: 12),
                        Gender = c.String(),
                        PhoneNumber = c.String(nullable: false),
                        Age = c.Int(nullable: false),
                        Flight_Id = c.Int(nullable: false),
                        Email = c.String(maxLength: 128),
                    })
                .PrimaryKey(t => t.Booking_id)
                .ForeignKey("dbo.Flights", t => t.Flight_Id, cascadeDelete: true)
                .ForeignKey("dbo.Registrations", t => t.Email)
                .Index(t => t.Flight_Id)
                .Index(t => t.Email);
            
            CreateTable(
                "dbo.CheckIns",
                c => new
                    {
                        Check_Id = c.Int(nullable: false),
                        Seat_Allocation = c.String(nullable: false),
                    })
                .PrimaryKey(t => t.Check_Id)
                .ForeignKey("dbo.Flights", t => t.Check_Id)
                .ForeignKey("dbo.Bookings", t => t.Check_Id)
                .Index(t => t.Check_Id);
            
            CreateTable(
                "dbo.Flights",
                c => new
                    {
                        FlightId = c.Int(nullable: false, identity: true),
                        Flight = c.String(nullable: false),
                        To = c.String(nullable: false),
                        From = c.String(nullable: false),
                        DateAndTime = c.DateTime(nullable: false),
                        Fare = c.Single(nullable: false),
                        seatAvailable = c.Int(nullable: false),
                    })
                .PrimaryKey(t => t.FlightId);
            
            CreateTable(
                "dbo.Registrations",
                c => new
                    {
                        Email = c.String(nullable: false, maxLength: 128),
                        FullName = c.String(),
                        Password = c.String(nullable: false),
                    })
                .PrimaryKey(t => t.Email);
            
        }
        
        public override void Down()
        {
            DropForeignKey("dbo.Bookings", "Email", "dbo.Registrations");
            DropForeignKey("dbo.CheckIns", "Check_Id", "dbo.Bookings");
            DropForeignKey("dbo.CheckIns", "Check_Id", "dbo.Flights");
            DropForeignKey("dbo.Bookings", "Flight_Id", "dbo.Flights");
            DropIndex("dbo.CheckIns", new[] { "Check_Id" });
            DropIndex("dbo.Bookings", new[] { "Email" });
            DropIndex("dbo.Bookings", new[] { "Flight_Id" });
            DropTable("dbo.Registrations");
            DropTable("dbo.Flights");
            DropTable("dbo.CheckIns");
            DropTable("dbo.Bookings");
        }
    }
}
