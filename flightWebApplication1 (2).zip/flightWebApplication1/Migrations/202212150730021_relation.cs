﻿namespace flightWebApplication1.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class relation : DbMigration
    {
        public override void Up()
        {
            DropForeignKey("dbo.Bookings", "Flight_Flight_Id", "dbo.Flights");
            DropIndex("dbo.Bookings", new[] { "Flight_Flight_Id" });
            RenameColumn(table: "dbo.Bookings", name: "Flight_Flight_Id", newName: "Flight_Id");
            AlterColumn("dbo.Bookings", "Flight_Id", c => c.Int(nullable: false));
            AlterColumn("dbo.Registrations", "FullName", c => c.String(nullable: false));
            CreateIndex("dbo.Bookings", "Flight_Id");
            AddForeignKey("dbo.Bookings", "Flight_Id", "dbo.Flights", "FlightId", cascadeDelete: true);
        }
        
        public override void Down()
        {
            DropForeignKey("dbo.Bookings", "Flight_Id", "dbo.Flights");
            DropIndex("dbo.Bookings", new[] { "Flight_Id" });
            AlterColumn("dbo.Registrations", "FullName", c => c.String());
            AlterColumn("dbo.Bookings", "Flight_Id", c => c.Int());
            RenameColumn(table: "dbo.Bookings", name: "Flight_Id", newName: "Flight_Flight_Id");
            CreateIndex("dbo.Bookings", "Flight_Flight_Id");
            AddForeignKey("dbo.Bookings", "Flight_Flight_Id", "dbo.Flights", "FlightId");
        }
    }
}
