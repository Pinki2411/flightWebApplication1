﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;
using System.Web.DynamicData;

namespace flightWebApplication1.Models
{

    [TableName("Flights")]
    public class Flight
    {
        
        [Key]
        [Column("FlightId")]
        public int Flight_Id { get; set; }

        [Column("Flight")]
        [Required(ErrorMessage = "Name is Required")]
        public string Name { get; set; }
        [Required(ErrorMessage = "To is Required")]
        public string To { get; set; }
        [Required(ErrorMessage = "From is Required")]
        public string From { get; set; }
        [Required(ErrorMessage = "Required to fill")]
        [Display(Name="Planned on")]
        public DateTime DateAndTime { get; set; }
        [Required(ErrorMessage = "Require to Fill")]
        public float Fare { get; set; }
        [Required]
        public int seatAvailable { get; set; }
        //Navigation property
        public virtual ICollection<Booking> Bookings { get; set; }  
        public virtual CheckIn CheckIn { get; set; }

    }
       public class Registration
        {
        [Required]
          public string FullName { get; set; }
           [Key]
            [Display(Name = "Email")]
            [DataType(DataType.EmailAddress)]
            [Required(ErrorMessage = "Email is Required")]
            public string Email { get; set; }
            [Display(Name = "Password")]
            [DataType(DataType.Password)]
            [Required(ErrorMessage = "Password is Required")]
            public string Password { get; set; }
        //Navigation property
        public virtual ICollection<Booking> Bookings { get; set; }  
        }
    public class Booking
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Booking_id { get; set; }
        [Required]
        public string Passenger_Name { get; set; }
        [Required]
        public string City { get; set; }
        [Required]
        public string Country { get; set; }
        [Required]
        [StringLength(12, ErrorMessage = "Passport_No Invalid")]
        public string Passport_No { get; set; }
        public string Gender { get; set; }
        [Required]

        [RegularExpression(@"^(\d{10})$", ErrorMessage = "PhoneNumber Must be 10 Digit Only")]

        public string PhoneNumber { get; set; }
        public int Age { get; set; }
        //Navigation Property
        public int Flight_Id { get; set; }
        public virtual Flight Flight { get; set; }
       
        public virtual Registration Registration { get; set; } 
        public virtual CheckIn CheckIn { get; set; }
    }

public class CheckIn
    {
        [Key]
        public int Check_Id { get; set; }
        [Required]
        [Display(Name = "Seatno.")]
        public string Seat_Allocation { get; set; }
      
         public virtual Booking Booking { get; set; }
        public virtual Flight Flight { get; set; }
        
    }

}
