﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.Entity;

namespace flightWebApplication1.Models
{
    public class FlightSYstemContext : DbContext
    {
        public DbSet<Flight> dbsetflight { get; set; }
        public DbSet<Registration> registrations { get; set; }
        public DbSet<Booking> bookings { get; set; }
        public DbSet<CheckIn> checkIns { get; set; }
        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Flight>().HasOptional(e => e.CheckIn)
                .WithRequired(a => a.Flight);
            modelBuilder.Entity<Booking>().HasOptional(e => e.CheckIn)
                .WithRequired(a => a.Booking);
            modelBuilder.Entity<Booking>().HasRequired(p => p.Flight)
                .WithMany(b => b.Bookings).HasForeignKey(b => b.Flight_Id);
         
            
        }
    }
}
