﻿using flightWebApplication1.Models;
using flightWebApplication1.Models.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http.Headers;
using System.Web;
using System.Web.Mvc;
using System.Web.Providers.Entities;

namespace flightWebApplication1.Controllers
{
    public class RegistrationController : Controller
    {

        private Ifunction<Registration> interfaceRobj = null;
        public RegistrationController()
        {
            this.interfaceRobj = new RepositoryClass<Registration>();
        }
        public RegistrationController(Ifunction<Registration> interfaceRobj)
        {
            this.interfaceRobj = interfaceRobj;
        }
        // GET: Registration
        public ActionResult Index()
        {
            Session["login"] = true;
            return RedirectToAction("Login", "Registration");
        }
        public ActionResult IndexS()
        {
            Session["Registration"] = true;
            return RedirectToAction("Create", "Registration");
        }
        public ActionResult Login()
        {
            return View();
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult LoginM(string email,string password)
        {
            if (ModelState.IsValid == true)
            {
                var user = interfaceRobj.GetModel().Where(model => model.Email == email && model.Password == password).FirstOrDefault();
                if (user == null)

                {
                    ViewBag.ErrorMessage("Login Failed !!!  Enter your Credentials Again....");
                    return RedirectToAction("Login","Registration");
                }
                else
                {
                    Session["UserName"] = email;
                    if (Session["Login"] != null)
                        return RedirectToAction("Search", "Flight");
                    else
                    return RedirectToAction("Create", "Booking");
                }
            }
            else

                return RedirectToAction("Login","Registration");
        }
        public ActionResult Create()
        {

            return View();
        }
        [HttpPost]
        public ActionResult Create(Registration a)
        {
            if (ModelState.IsValid == true)
            {
                interfaceRobj.InsertModel(a);
                if (Session["Registration"] != null)
                    return RedirectToAction("Search", "Flight");
                else
                    return RedirectToAction("Create", "Booking");
            }
            else
                return RedirectToAction("Create", "Registration");
        }
    }
}
                
            
        
   