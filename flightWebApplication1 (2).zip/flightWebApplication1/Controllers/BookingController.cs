﻿using flightWebApplication1.Models.Repository;
using flightWebApplication1.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace flightWebApplication1.Controllers
{
    public class BookingController : Controller
    {
        private Ifunction<Booking> interfaceBObj = null;
        private Ifunction<Flight> interfaceFObj=null;
        private Ifunction<Registration> interfaceRObj = null;
        public BookingController()
        {
            this.interfaceBObj = new RepositoryClass<Booking>();
            this.interfaceFObj= new RepositoryClass<Flight>();  
            this.interfaceRObj= new RepositoryClass<Registration>();    
        }
        public BookingController(Ifunction<Booking> interfaceBObj)
        {
            this.interfaceBObj = interfaceBObj;
        }
        // GET: Booking
        public ActionResult Index()
        {
            var data = from m in interfaceBObj.GetModel() select m;
            return View(data);
        }
        public ActionResult Create()
        {
            if (Session["Username"]==null)
            {
                return RedirectToAction("Login", "Registration");
            }
            else
            return View();
        }
        [HttpPost]
        public ActionResult Create(Booking booking)
        {
            
            interfaceBObj.InsertModel(booking);
            return RedirectToAction("Index");
        }

    }
}